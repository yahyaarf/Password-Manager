#include <string.h>
#include "encryption.h"

void Encrypt(char *data, const char *key, int data_length) {
    int key_length = strlen(key); //characters are in the data string. if the data = 'HelloWorld' => 10
    for (int i = 0; i < data_length; i++) {
        data[i] = data[i] ^ key[i % key_length];
    }
}

void Decrypt(char *data, const char *key, int data_length) {
    Encrypt(data, key, data_length);
}


