#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include "password_storage.h"
#include "encryption.h"


void Save_Password(const char *service, const char *encrypted_password, const char *key) {
    int fd = open("passwords.txt", O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (fd < 0) {
        perror("Error opening file");
        return;
    }

    int encrypted_length = 15;

    // Convert encrypted password to hexadecimal
    char hex_encrypted_password[512];
    for (int i = 0; i < encrypted_length; i++) {
        snprintf(&hex_encrypted_password[i * 2], 3, "%02x", (unsigned char)encrypted_password[i]);
    }

    // Decrypt the password safely
    char decrypted_password[256];
    strncpy(decrypted_password, encrypted_password, encrypted_length);
    decrypted_password[encrypted_length] = '\0'; // Ensure null-termination
    Decrypt(decrypted_password, key, encrypted_length); // Decrypt in place

    // Format of the entry
    char buffer[512];
    int length = snprintf(buffer, sizeof(buffer),"| %-14s | %-32s |  %s   |\n", service, hex_encrypted_password, decrypted_password);

    // Write the entry to the file
    if (write(fd, buffer, length) < 0) {
        perror("Error writing to file");
    } else {
        printf("Password saved successfully for service: %s\n", service);
    }
    close(fd);
}



//void Retrieve_Password(const char *service, const char *key) {
//    int fd = open("passwords.txt", O_RDONLY);
//    if (fd < 0) {
//        perror("Error opening file");
//        return;
//    }
//
//    char buffer[512];
//    char stored_service[100], hex_encrypted_password[512], stored_key[256];
//    char line[256];
//    int found = 0;
//    ssize_t bytes_read;
//    int line_index = 0;
//
//    printf("DEBUG: Searching for service '%s'...\n", service);
//
//
//    while ((bytes_read = read(fd, buffer, sizeof(buffer))) > 0) {
//        for (ssize_t i = 0; i < bytes_read; i++) {
//            if (buffer[i] == '\n') {
//                
//                line[line_index] = '\0';
//               
//                if (sscanf(line, "%[^|]|%[^|]|%s", stored_service, hex_encrypted_password, stored_key) == 3) {
//           
//                    stored_service[strcspn(stored_service, "\n")] = '\0';
//                    while (strlen(stored_service) > 0 &&
//                           stored_service[strlen(stored_service) - 1] == ' ') {
//                        stored_service[strlen(stored_service) - 1] = '\0';
//                    }
//                    printf("DEBUG: Checking service: '%s'\n", stored_service);
//       
//                    if (strcmp(stored_service, service) == 0) {
//                        found = 1;
//              
//                        char raw_encrypted_password[256];
//                        int encrypted_length = strlen(hex_encrypted_password) / 2;
//                        for (int j = 0; j < encrypted_length; j++) {
//                            sscanf(&hex_encrypted_password[j * 2], "%2hhx", &raw_encrypted_password[j]);
//                        }
//     
//                        char decrypted_password[256];
//                        memcpy(decrypted_password, raw_encrypted_password, encrypted_length);
//                        decrypted_password[encrypted_length] = '\0'; // Null-terminate
//
//                        Decrypt(decrypted_password, key, encrypted_length);
//
//                        printf("Service: %s\n", stored_service);
//                        printf("Decrypted Password: %s\n", decrypted_password);
//
//                        close(fd);
//                        return;
//                    }
//                }
//                // Reset the line buffer for the next line
//                line_index = 0;
//            } else {
//                line[line_index++] = buffer[i];
//            }
//        }
//    }
//    if (!found) {
//        printf("Service not found: %s\n", service);
//    }
//    close(fd);
//}

//

//void Save_Password(const char *service, const char *encrypted_password, const char *key) {
//    // Open the file in append mode to preserve existing data and add new entries
//    int fd = open("passwords.txt", O_WRONLY | O_CREAT | O_APPEND, 0644);
//
//    // Decrypt the password
//    char decrypted_password[256];
//    strcpy(decrypted_password, encrypted_password); // Copy encrypted password
//    Decrypt(decrypted_password, key, strlen(encrypted_password)); // Decrypt it
//
//    // Format the entry with spaces around the delimiters
//    char buffer[512];
//    int length = snprintf(buffer, sizeof(buffer), "%s|%s|%s\n", service, encrypted_password, decrypted_password);
//    //printf("the lenghtttttttttttt: %d",length);
//    // Write to the file
//    if (write(fd, buffer, length) < 0) {
//        perror("Error writing to file");
//    } else {
//        printf("Password saved successfully for service: %s\n", service);
//    }
//    ssize_t count = write(fd, buffer, length);
//    printf("HAHAHHAHAHA: %zd", count);
//    close(fd);
//}

