#ifndef ENCRYPTION_H
#define ENCRYPTION_H

void Encrypt(char *data, const char *key, int data_length);
void Decrypt(char *data, const char *key, int data_length);

#endif
