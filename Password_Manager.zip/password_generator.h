#ifndef PASSWORD_GENERATOR_H
#define PASSWORD_GENERATOR_H


char *Generate_Password(int Pass_length);
char *Generate_Key(int Key_length);
int Check_Password_Strength(const char *password);
char *Generate_Custom_Password(void);

#endif
