#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <fcntl.h>
#include <unistd.h> //random seed, getpid()
#include "password_storage.h"
#include "password_generator.h"
#include "encryption.h"

int Check_Password_Strength(const char *password) {
    int length = strlen(password);
    int has_upper = 0, has_lower = 0, has_digit = 0, has_special = 0;

    for (int i = 0; i < length; i++) {
        if (isupper(password[i])) {
            has_upper = 1;
        } else if (islower(password[i])) {
            has_lower = 1;
        } else if (isdigit(password[i])) {
            has_digit = 1;
        } else if (strchr("!@#$%^&*()", password[i])) {
            has_special = 1;
        }
    }

    if (length >= 8 && has_upper && has_lower && has_digit && has_special) {
        return 1; // Strong password
    }
    return 0; // Weak password
}


char *Generate_Custom_Password() {
    char buffer[256]; 
    printf("Enter your custom password: ");
    scanf("%255s", buffer); // Read up to 255 characters from user

    if (Check_Password_Strength(buffer)) {
        printf("Password Strength: Strong\n");
    } else {
        printf("Password Strength: Weak\n");
        printf("A strong password must be at least 8 characters long and contain uppercase, lowercase, a digit, and a special character.\n");
    }
    // Allocate memory for the custom password
    char *Password = malloc(strlen(buffer) + 1);


    strcpy(Password, buffer);
    return Password;
}



int main(int argc, const char *argv[]) {
    char *password = NULL;
    char *Key = NULL;
    const int Pass_length = 15;
    const int Key_length = 15;
    char Service[100];
    
    printf("Do you want to generate a random password or set a custom password? (R/C): ");
    char choice;
    scanf(" %c", &choice);

if (choice == 'R' || choice == 'r') {
    printf("Enter the name of the service: ");
    scanf("%99s", Service);
    password = Generate_Password(Pass_length);
    Key = Generate_Key(Key_length);
    printf("Generated Random Password: %s\n", password);
    printf("Generated Random Key: %s\n", Key);
    
    // Create a copy of the original password before encryption
    char original_password[256];
    strcpy(original_password, password);
    
    Encrypt(password, Key, Pass_length);
    printf("Encrypted Password (hex): ");
    for (int i = 0; i < Pass_length; i++) {
        printf("%02x", (unsigned char)password[i]);
    }
    printf("\n");
    printf("the Decrypted password: ");
    Decrypt(password, Key, Pass_length);
    // Save the encrypted password
    Save_Password(Service, password, Key);
    } else if (choice == 'C' || choice == 'c') {
        printf("Enter the name of the service: ");
        scanf("%99s", Service);
        password = Generate_Custom_Password();
        Key = Generate_Key(Key_length);
        printf("Password: %s\n", password);
        printf("Generated Random Key: %s\n", Key);
        Encrypt(password, Key, Pass_length);
        printf("Encrypted Password: ");
        for (int i = 0; i < Pass_length; i++) {
            printf("%02x", (unsigned char)password[i]); // Print in hexadecimal
        }
        printf("\n");
        Save_Password(Service, password, Key);
    } else {
        printf("Invalid choice! Exiting.\n");
        return -1;
    }

    free(password);
    free(Key);

    return 0;
}

//#include <stdio.h>
//#include <stdlib.h>
//#include <string.h>
//#include <ctype.h>
//#include <fcntl.h>
//#include <unistd.h> //rand
//#include "password_storage.h"
//#include "password_generator.h"
//#include "encryption.h"
//
//
//
//int Check_Password_Strength(const char *password) {
//    int length = strlen(password);
//    int has_upper = 0, has_lower = 0, has_digit = 0, has_special = 0;
//
//    for (int i = 0; i < length; i++) {
//        if (isupper(password[i])) {
//            has_upper = 1;
//        } else if (islower(password[i])) {
//            has_lower = 1;
//        } else if (isdigit(password[i])) {
//            has_digit = 1;
//        } else if (strchr("!@#$%^&*()", password[i])) {
//            has_special = 1;
//        }
//    }
//
//    if (length >= 8 && has_upper && has_lower && has_digit && has_special) {
//        return 1; // Strong password
//    }
//    return 0; // Weak password
//}
//
//
//char *Generate_Custom_Password() {
//    char buffer[256]; // Temporary buffer for user input
//    printf("Enter your custom password: ");
//    scanf("%255s", buffer); // Read up to 255 characters from user
//
//    if (Check_Password_Strength(buffer)) {
//        printf("Password Strength: Strong\n");
//    } else {
//        printf("Password Strength: Weak\n");
//        printf("A strong password must be at least 8 characters long and contain uppercase, lowercase, a digit, and a special character.\n");
//    }
//    // Allocate memory for the custom password
//    char *Password = malloc(strlen(buffer) + 1);
//
//
//    strcpy(Password, buffer); // Copy the user input to the allocated memory
//    return Password;
//}
//
//
//int main(int argc, const char *argv[]) {
//   
//    char *password = NULL;
//    char *Key = NULL;
//    int Pass_length = 15;
//    int Key_length = 15;
//    
//    printf("Do you want to generate a random password or set a custom password? (R/C): ");
//    char choice;
//    scanf(" %c", &choice); // Read user choice (R or C)
//
//    if (choice == 'R' || choice == 'r') {
//        password = Generate_Password(Pass_length);
//        Key = Generate_Key(Key_length);
//        printf("Generated Random Password: %s\n", password);
//        printf("Generated Random Key: %s\n", Key);
//        Encrypt(password, Key, Pass_length);
//        printf("Encrypted Password: ");
//        for (int i = 0; i < Pass_length; i++) {
//            printf("%02x", (unsigned char)password[i]); // Print each byte in hexadecimal
//        }
//        printf("\n");
//        
//    } else if (choice == 'C' || choice == 'c') {
//        password = Generate_Custom_Password();
//        Key = Generate_Key(Key_length);
//        printf("Password: %s\n", password);
//        printf("Generated Random Key: %s\n", Key);
//        Encrypt(password, Key, Pass_length);
//        printf("Encrypted Password: ");
//        for (int i = 0; i < Pass_length; i++) {
//            printf("%02x", (unsigned char)password[i]); // Print each byte in hexadecimal
//        }
//        printf("\n");
//        
//    } else {
//        printf("Invalid choice! Exiting.\n");
//        return -1;
//    }
//
//
//    Decrypt(password, Key, Pass_length);
//    printf("Decrypted Password: %s\n", password);
//    
//    // Save a password
//    Save_Password("Facebook", password, Key);
//
//    // Retrieve a password
//    Retrieve_Password("Facebook", Key);
//    
//    // Free the allocated memory for the password
//    free(password);
//    free(Key);
//
//    return 0;
//}


