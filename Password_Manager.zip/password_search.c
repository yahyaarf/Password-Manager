#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>

void searchPassword(const char *file, const char *platform) {
    int fd = open(file, O_RDONLY);
    if (fd < 0) {
        perror("Error opening file");
        return;
    }

    char buf[1];
    char line[512];
    int lineIndex = 0;

    while (read(fd, buf, 1) > 0) {
        if (buf[0] == '\n' || lineIndex >= sizeof(line) - 1) {
            line[lineIndex] = '\0'; // Null-terminate the line
            if (strstr(line, platform)) { // Check if the line contains the platform
                char *p = strrchr(line, '|');
                if (p) {
                    printf("Password for %s: %s\n", platform, p + 2);
                    close(fd);
                    return;
                }
            }
            lineIndex = 0; // Reset for the next line
        } else {
            line[lineIndex++] = buf[0]; // Add character to the line buffer
        }
    }

    printf("Service '%s' not found\n", platform);
    close(fd);
}

int main(int argc, char *argv[]) {

    const char *filename = argv[1];
    const char *platform = argv[2];

    searchPassword(filename, platform);
    return 0;
}







//#include <fcntl.h>
//#include <unistd.h>
//#include <string.h>
//#include <stdio.h>
//
//void searchPassword(const char *file, const char *platform) {
//    int fd = open(file, O_RDONLY);
//    if (fd < 0) {
//        perror("Error opening file");
//        return;
//    }
//
//    char buf[1];
//    char line[512];
//    int lineIndex = 0;
//
//    while (read(fd, buf, 1) > 0) { // Read one character at a time
//        if (buf[0] == '\n' || lineIndex >= sizeof(line) - 1) {
//            line[lineIndex] = '\0'; // Null-terminate the line
//
//            // Skip the separator line (dashes or dots)
//            if (strchr(line, '-') || strchr(line, '.')) {
//                lineIndex = 0;
//                continue;
//            }
//
//            // Parse the formatted line
//            char service[32], encrypted_password[64], decrypted_password[64];
//            if (sscanf(line, "| %14[^|] | %32[^|] |  %[^|]  |", service, encrypted_password, decrypted_password) == 3) {
//                // Trim leading/trailing spaces from service
//                char *trimmed_service = strtok(service, " ");
//                if (strcmp(trimmed_service, platform) == 0) {
//                    printf("Password for %s: %s\n", platform, decrypted_password);
//                    close(fd);
//                    return;
//                }
//            }
//            lineIndex = 0; // Reset for the next line
//        } else {
//            line[lineIndex++] = buf[0]; // Add character to the line buffer
//        }
//    }
//
//    printf("Platform '%s' not found\n", platform);
//    close(fd);
//}
//
//
//int main(int argc, char *argv[]) {
//
//    const char *filename = argv[1];
//    const char *Service = argv[2];
//
//    searchPassword(filename, Service);
//    return 0;
//}



