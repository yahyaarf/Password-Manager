#ifndef PASSWORD_STORAGE_H
#define PASSWORD_STORAGE_H

void Save_Password(const char *service, const char *encrypted_password, const char *key);
void Retrieve_Password(const char *service, const char *key);

#endif 
