#include <stdio.h>
#include <string.h>
#include <stdlib.h>//memory alocation
#include <time.h>
#include <unistd.h>
#include <ctype.h>
#include "password_generator.h"


// Generate a random password
char *Generate_Password(int Pass_length) {
    char *Password = malloc(Pass_length + 1);
    if (!Password) {
        printf("Error: Memory allocation failed!\n");
        return NULL;
    }
    char *digits = "0123456789";
    char *lowercase = "abcdefghijklmnopqrstuvwxyz";
    char *uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    char *symbols = "!@#$%^&()_+=";

    
    srand(time(NULL) * getpid());

    for (int i = 0; i < Pass_length; i++) {
        int char_type = rand() % 4; // 0 1 2 3 by mudulousing anynumber
        switch (char_type) {
            case 0:
                Password[i] = digits[rand() % strlen(digits)];
                break;
            case 1:
                Password[i] = lowercase[rand() % strlen(lowercase)];
                break;
            case 2:
                Password[i] = uppercase[rand() % strlen(uppercase)];
                break;
            case 3:
                Password[i] = symbols[rand() % strlen(symbols)];
                break;
        }
    }
    Password[Pass_length] = '\0'; // Null-terminate
    return Password;
}

// Generate a random key
char *Generate_Key(int Key_length) {
    char *Key = malloc(Key_length + 1); // Allocate memory for the key
    if (!Key) {
        printf("Error: Memory allocation failed!\n");
        return NULL;
    }

    char *digits = "1357902468";
    char *lowercase = "spaojntkmdxqghuiczfrlvywbe";
    char *uppercase = "POFXGRSJNYVUHECIZWTKAQDLBM";
    char *symbols = ")&@$!=#^_+(%";

    srand(time(NULL) * getpid());

    for (int i = 0; i < Key_length; i++) {
        int char_type = rand() % 4;
        switch (char_type) {
            case 0:
                Key[i] = digits[rand() % strlen(digits)];
                break;
            case 1:
                Key[i] = lowercase[rand() % strlen(lowercase)];
                break;
            case 2:
                Key[i] = uppercase[rand() % strlen(uppercase)];
                break;
            case 3:
                Key[i] = symbols[rand() % strlen(symbols)];
                break;
        }
    }
    Key[Key_length] = '\0';
    return Key;
    
}




